package com.ukim.mk.projectspring.repo;

import com.ukim.mk.projectspring.model.Firm;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FirmRepository extends JpaRepository<Firm, Integer> {


}