package com.ukim.mk.projectspring.model.enumerations;

public enum ShoppingCartStatus {
    CREATED,
    CANCELED,
    FINISHED
}

